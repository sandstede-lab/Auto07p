
________________________________________________________________________________

FINITE_DIFF_SH_PHASE

run Auto: c=par(4) is the wave speed and par(5) is the number of stable eigenvalues

> @r finite_diff_SH_phase
> more fort.7
> more fort.9
> @sv phase
> autox to_matlab.xauto phase run

in Matlab:

> sh_plot_solution

________________________________________________________________________________

FINITE_DIFF_SH_HALF

run Auto:

> @r finite_diff_SH_half
> more fort.7
> more fort.9
> @sv half
> autox to_matlab.xauto phase run

________________________________________________________________________________

