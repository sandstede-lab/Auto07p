
README file for auto_SH_half.f and auto_SH_phase.f
_______________________________________________________________________________

1. Symmetric localized rolls on the half line [0,L] with L large

- Uses AUTO file: auto_SH_half.f
- Purpose: solves the boundary-value problem associated with the Swift-Hohenberg equation on the interval [0,L] with Neumann boundary conditions.
- Initial condition: Takes the symmetric localized pulse on [0,L] centered at x=0 stored in auto_SH_half.dat which was produced by the Matlab routine solve_SH1D_finite_half.m
- How to run: To run auto_SH_half, type the following at the command line:
> @r auto_SH_half
_______________________________________________________________________________

2. Localized rolls on the line [-L/2,L/2] with L large

- Uses AUTO file: auto_SH_phase.f
- Purpose: solves the boundary-value problem associated with the Swift-Hohenberg equation on the interval [-L/2,L/2] with Neumann boundary conditions and a phase condition.
- Initial condition: Takes a localized pulse on [-L/2,L/2] centered at x=0 stored in auto_SH_phase.dat which was produced by the Matlab routine solve_SH1D_finite_full.m
- How to run: To run auto_SH_phase, type the following at the command line:
> @r auto_SH_phase
_______________________________________________________________________________

