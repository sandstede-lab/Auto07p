
AUTO:

type the following in a terminal to run Auto and plot the solutions:
	@r pulse
	@pp

The initial data for 'pulse' are in the file sech.dat. This file was created in Matlab using the commands:
	x=[-10:0.2:10];
	u=sqrt(2)*sech(x);
	up = diff(u);
	up(101) = 0.0;
	A = [x;u;up]';
	save('sech.dat','A','-ascii','-double')
