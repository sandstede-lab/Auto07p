AUTO_DIR=~/auto/07p
PATH="~/auto/07p:~/auto/07p/bin:./:$PATH"
export PATH
export AUTO_DIR